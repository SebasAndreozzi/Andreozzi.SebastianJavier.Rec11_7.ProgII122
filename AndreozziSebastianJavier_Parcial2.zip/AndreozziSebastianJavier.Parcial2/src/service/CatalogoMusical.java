/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import model.CSVSerializable;

/**
 *
 * @author sebas
 */
public class CatalogoMusical<T extends CSVSerializable & Comparable<T>>{
    
    List<T> items = new ArrayList<>();
    
    private void validarNull(T item){
        if(item == null){
            throw new NullPointerException("El elemento no puede ser null.");
        }
    }
    
    private void valdiarItemRepetido(T item){
        if(items.contains(item)){
            throw new IllegalArgumentException("No cargar items repetidos.");
        }
    }
    
    private void validarIndice(int indice){
        if(indice < 0 || indice > items.size()){
            throw new IndexOutOfBoundsException("Indice fuera de rango");
        }
    }
    
    public void agregar(T item) {
        validarNull(item);
        valdiarItemRepetido(item);
        
        items.add(item);
    }
    
    public void eliminarPorIndice(int indice){
        validarIndice(indice);
        
        items.remove(items.get(indice));
    }
    
    public T obtenerPorIndice(int indice){
        validarIndice(indice);

        return items.get(indice);
    } 
    
    public List<T> filtrar(Predicate<? super T> criterio){
        
        List<T> toReturn = new ArrayList<>();
        
        for(T elemento: items){
            if(criterio.test(elemento)){
                toReturn.add(elemento);
            }
        }
        
        return toReturn;
    }

    public void ordenar() {
        Collections.sort(items);
    }
    
    public void ordenar(Comparator<T> comparador) {
        Collections.sort(items, comparador);
    }

    public void paraCadaElemento(Consumer<? super T> accion) {
        for(T item : items){
            accion.accept(item);
        }
    }
    
    public void guardarEnArchivo(String path)throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(path))) {
            oos.writeObject(items);
        }
    }

        
    public void cargarDesdeArchivo(String path)throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(path))) {
            items = (List<T>) ois.readObject();
        }
    }

    public void guardarEnCSV(String path)throws IOException {
        try (PrintWriter pw = new PrintWriter(new FileWriter(path))) {
            for (T item : items) {
                pw.println(item.toCSV());
            }
        }
    }
    
    public void cargarDesdeCSV(String path, Function<String, T> fromCSV)throws IOException {
        items.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (!linea.trim().isEmpty()) {
                    T obj = fromCSV.apply(linea);
                    items.add(obj);
                }
            }
        }
    
    }
}
