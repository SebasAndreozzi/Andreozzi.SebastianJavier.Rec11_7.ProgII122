/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Objects;

/**
 *
 * @author sebas
 */
public class Cancion implements Comparable<Cancion>, CSVSerializable{
    
    private static final long serialVersionUID = 1L;
    
    int id;
    String titulo;
    String artista;
    GeneroMusical genero;

    public Cancion(int id, String titulo, String artista, GeneroMusical genero) {
        this.id = id;
        this.titulo = titulo;
        this.artista = artista;
        this.genero = genero;
    }    

    public GeneroMusical getGenero() {
        return genero;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getArtista() {
        return artista;
    }

    @Override
    public String toString() {
        return "Cancion{" + "id=" + id + ", titulo=" + titulo + ", artista=" + artista + ", genero=" + genero + '}';
    }
    
    @Override
    public int compareTo(Cancion c) {
        return Integer.compare(id, c.id);
    }
    
    @Override
    public boolean equals(Object o){
        if(o == null || !(o instanceof Cancion c)){
            return false;
        }
        return this.id == c.id && this.titulo.equals(c.titulo) && this.artista.equals(c.artista) && this.genero == c.genero;
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(id, titulo, artista, genero);
    }
    
    public static Cancion fromCSV(String cancionesCSV){
        
        if(cancionesCSV.endsWith("\n")){
            cancionesCSV = cancionesCSV.substring(0, cancionesCSV.length() - 1); 
        }
        
        String[] atributos = cancionesCSV.split(",");
        
        int id = Integer.parseInt(atributos[0]);
        String titulo = atributos[1];
        String artista = atributos[2];
        GeneroMusical genero = GeneroMusical.valueOf(atributos[3].strip());
        
        return new Cancion(id, titulo, artista, genero);
    }
    
    @Override
    public String toCSV(){
        return id + "," + titulo + "," + artista + "," + genero;
    }
    
    public static String toCSVHeader(){
        return "id, titulo, artista, genero";
    }
}
