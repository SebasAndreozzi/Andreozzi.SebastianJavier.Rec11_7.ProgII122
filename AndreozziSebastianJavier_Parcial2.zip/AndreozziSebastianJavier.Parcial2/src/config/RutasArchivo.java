/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package config;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *
 * @author sebas
 */
public interface RutasArchivo {
    
    final String BASE = "src/data";
    final String FILE_CSV = "canciones.csv";
    final String FILE_BIN = "canciones.dat";
    
    static Path getRutaCSV(){
        return Paths.get(BASE, FILE_CSV);
    }
    
    static String getRutaCSVString(){
        return getRutaCSV().toString();
    }
    
    static Path getRutaBin(){
        return Paths.get(BASE, FILE_BIN);
    }
    
    static String getRutaBinString(){
        return getRutaBin().toString();
    }
}
