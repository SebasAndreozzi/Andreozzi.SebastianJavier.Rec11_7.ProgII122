/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package andreozzisebastianjavier.parcial2;

import config.RutasArchivo;
import java.io.IOException;
import model.Cancion;
import service.CatalogoMusical;
import model.GeneroMusical;

public class AndreozziSebastianJavierParcial2 {

 public static void main(String[] args) {
     try{
        CatalogoMusical<Cancion> catalogo = new CatalogoMusical<>();
        
        catalogo.agregar(new Cancion(1, "Bohemian Rhapsody", "Queen", GeneroMusical.ROCK));
        catalogo.agregar(new Cancion(2, "Billie Jean", "Michael Jackson",
       GeneroMusical.POP));
        catalogo.agregar(new Cancion(3, "Shape of You", "Ed Sheeran", GeneroMusical.POP));
        catalogo.agregar(new Cancion(4, "Take Five", "Dave Brubeck", GeneroMusical.JAZZ));
        catalogo.agregar(new Cancion(5, "Canon in D", "Pachelbel", GeneroMusical.CLASICA));
        
        System.out.println("Catálogo de canciones:");
        catalogo.paraCadaElemento(System.out::println);
        
        System.out.println("\nCanciones de género JAZZ:");
        catalogo.filtrar(c -> c.getGenero() == GeneroMusical.JAZZ)
        .forEach(System.out::println);
        
        System.out.println("\nCanciones cuyo título contiene 'five':");
        catalogo.filtrar(c -> c.getTitulo().contains("Five"))
        .forEach(System.out::println);
        
        System.out.println("\nCanciones ordenadas por ID:");
        catalogo.ordenar();
        catalogo.paraCadaElemento(System.out::println);
        
        System.out.println("\nCanciones ordenadas por artista:");
        catalogo.ordenar((c1, c2) -> c1.getArtista().compareTo(c2.getArtista()));
        catalogo.paraCadaElemento(System.out::println);
        
        catalogo.guardarEnArchivo(RutasArchivo.getRutaBinString());
        
        CatalogoMusical<Cancion> cargado = new CatalogoMusical<>();
        
        cargado.cargarDesdeArchivo(RutasArchivo.getRutaBinString());
        System.out.println("\nCanciones cargadas desde binario:");
        cargado.paraCadaElemento(System.out::println);
        
        catalogo.guardarEnCSV(RutasArchivo.getRutaCSVString());
        cargado.cargarDesdeCSV(RutasArchivo.getRutaCSVString(), li -> Cancion.fromCSV(li));
        System.out.println("\nCanciones cargadas desde CSV:");
        cargado.paraCadaElemento(System.out::println);
        
        }catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
 }
    
}
