/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package config;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *
 * @author sebas
 */
public interface AppConfig {
    final String BASE = "src/resources";
    public static final Path PATH_CSV = Paths.get(BASE, "eventos.csv");
    public static final Path PATH_SER = Paths.get(BASE, "eventos.bin");
    public static final Path PATH_JSON = Paths.get(BASE, "eventos.json");
    
}
