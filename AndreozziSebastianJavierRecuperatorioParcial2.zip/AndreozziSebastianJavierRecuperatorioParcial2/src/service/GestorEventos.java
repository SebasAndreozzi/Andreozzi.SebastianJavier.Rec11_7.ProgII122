/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import config.LocalDateAdapter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import model.CSVSerializable;
import model.EventoMusical;
import model.Gestionable;

/**
 *
 * @author sebas
 */
public class GestorEventos<T extends CSVSerializable & Comparable<T>> implements Gestionable<T>{
    
    List<T> eventos = new ArrayList<>();
    
    private void validarNull(T evento){
        if(evento == null){
            throw new NullPointerException("El elemento no puede ser null.");
        }
    }
    
    private void valdiarItemRepetido(T evento){
        if(eventos.contains(evento)){
            throw new IllegalArgumentException("No cargar elementos repetidos.");
        }
    }
    
    private void validarIndice(int indice){
        if(indice < 0 || indice > eventos.size()){
            throw new IndexOutOfBoundsException("Indice fuera de rango");
        }
    }
    
    @Override
    public void agregar(T evento) {
        validarNull(evento);
        valdiarItemRepetido(evento);
        
        eventos.add(evento);
    }

    @Override
    public void eliminar(int indice) {
        validarIndice(indice);
        
        eventos.remove(indice);
    }

    @Override
    public T obtener(int indice) {
       validarIndice(indice);
        
        return eventos.get(indice);
    }

    @Override
    public void limpiar() {
        eventos.clear();
    }

    @Override
    public void ordenar() {
        Collections.sort(eventos);
    }

    @Override
    public void ordenar(Comparator<T> comparador) {
        Collections.sort(eventos, comparador);
    }

    @Override
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> toReturn = new ArrayList<>();
        
        for(T elemento: eventos){
            if(criterio.test(elemento)){
                toReturn.add(elemento);
            }
        }
        
        return toReturn;
    }

    @Override
    public void guardarEnBinario(String path) throws IOException{
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(path))) {
            oos.writeObject(eventos);
        }
    }

    @Override
    public void cargarDesdeBinario(String path) throws IOException, ClassNotFoundException {
        try (ObjectInputStream salida = new ObjectInputStream(new FileInputStream(path))) {
            eventos = (List<T>) salida.readObject();
        }
    }

    @Override
    public void guardarEnCSV(String path) throws IOException {
        try (PrintWriter pw = new PrintWriter(new FileWriter(path))) {
            for (T e : eventos) {
                pw.println(e.toCSV());
            }
        }
    }

    @Override
    public void cargarDesdeCSV(String path, Function<String, T> fromCSV) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            eventos.clear();
            String linea;
            while ((linea = br.readLine()) != null) {
                if (!linea.trim().isEmpty()) {
                    T evento = fromCSV.apply(linea);
                    eventos.add(evento);
                }
            }
        }
    }

    @Override
    public void mostrarTodos() {
        eventos.forEach(System.out::println);
    }
    
    public void guardarEnJSON(String path) throws IOException {
        Gson gson = new GsonBuilder().registerTypeAdapter(LocalDate.class, new LocalDateAdapter()).create();
        JsonElement guardar = gson.toJsonTree(eventos);
        
        try (JsonWriter jw = new JsonWriter(new FileWriter(path))) {
            gson.toJson(guardar, jw);
        }
    }
    
    public void cargarDesdeJSON(String path) throws IOException {
        Gson gson = new GsonBuilder().registerTypeAdapter(LocalDate.class, new LocalDateAdapter()).create();
        Type listType = new TypeToken<List<EventoMusical>>(){}.getType();
        
        try (JsonReader jr = new JsonReader(new FileReader(path))) {
            List<T> cargadas = gson.fromJson(jr, listType);
            
            if (cargadas != null){
                cargadas.forEach(this::validarNull);
            }
            
            eventos.addAll(cargadas);
        }
    }
    
}
