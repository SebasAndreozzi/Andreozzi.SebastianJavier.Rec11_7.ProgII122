/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package model;

import java.time.LocalDate;
import java.util.Objects;

/**
 *
 * @author sebas
 */
public class EventoMusical extends Evento implements Comparable<EventoMusical>{
    
    private static final long serialVersionUID = 1L;
    
    private String artista;
    private GeneroMusical genero;
    
    public EventoMusical(int id, String nombre, LocalDate fecha, String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }
    
    public String getEquipoPrincipal() {
        return artista;
    }

    public GeneroMusical getCategoria() {
        return genero;
    }
      
    public static EventoMusical fromCSV(String eventosMusicalesCSV){
        
        if(eventosMusicalesCSV.endsWith("\n")){
            eventosMusicalesCSV = eventosMusicalesCSV.substring(0, eventosMusicalesCSV.length() - 1); 
        }
        
        String[] atributos = eventosMusicalesCSV.split(",");
        
        int id = Integer.parseInt(atributos[0]);
        String nombre = atributos[1];
        LocalDate fecha = LocalDate.parse(atributos[2]);
        String artista = atributos[3];
        GeneroMusical genero = GeneroMusical.valueOf(atributos[4].strip());
        
        return new EventoMusical(id, nombre, fecha, artista, genero);
    }
    
    @Override
    public String toCSV() {
        return super.getId() + "," + super.getNombre() + "," + super.getFecha() + "," + artista + "," +genero;
    }
    
    public static String toCSVHeader(){
        return "id, nombre, fecha, artista, genero";
    }
    
    @Override
    public int compareTo(EventoMusical em) {
        return super.getFecha().compareTo(em.getFecha());
    }
    
    @Override
    public boolean equals(Object o){
        if(o == null || !(o instanceof EventoMusical em)){
            return false;
        }
        return super.getFecha().equals(em.getFecha());
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(super.getFecha());
    }

    @Override
    public String toString() {
        
        return "EventoMusical{" + "id=" + super.getId() + ", nombre=" + super.getNombre() + ", fecha=" + super.getFecha() + ", artista=" + artista + ", genero=" + genero + '}';
    }



}
