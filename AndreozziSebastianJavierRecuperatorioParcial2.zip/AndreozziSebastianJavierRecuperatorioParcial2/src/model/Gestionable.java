/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package model;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 *
 * @author sebas
 */
public interface Gestionable<T> {            
    void agregar(T t);
    void eliminar(int indice);
    T obtener(int indice);
    void limpiar();
    
    void ordenar();
    void ordenar(Comparator<T> comparador);
    List<T> filtrar(Predicate<? super T> criterio);
    
    void guardarEnBinario(String path)throws IOException;
    void cargarDesdeBinario(String path)throws IOException, ClassNotFoundException;
    void guardarEnCSV(String path)throws IOException;
    void cargarDesdeCSV(String path, Function<String, T> fromCSV)throws IOException;
    
    void mostrarTodos();
}
